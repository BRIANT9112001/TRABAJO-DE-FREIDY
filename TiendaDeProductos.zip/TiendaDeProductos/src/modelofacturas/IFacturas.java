package modelofacturas;

import java.util.Date;

public interface IFacturas {
	int getId();
	Date getFecha();
}