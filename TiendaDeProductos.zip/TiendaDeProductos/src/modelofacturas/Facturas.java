package modelofacturas;

import java.util.Date;

public class Facturas extends FacturaBase {

	public Facturas(int id, Date fecha) {
		super(id, fecha);
	}
}
