package modelocliente;

public interface ICliente {
	  int getId();
	  String getNombre();
	  String getDetallecontacto();
	  String getTipocontacto();
}