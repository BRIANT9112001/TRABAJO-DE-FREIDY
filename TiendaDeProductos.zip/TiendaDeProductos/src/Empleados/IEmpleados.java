package Empleados;

public interface IEmpleados {
	int getId();
	String getNombre();
	String getEmail();
	String getPosicion();
	String getSalario();
}


	 
