/**
 * 
 */
/**
 * 
 */
module windowb {
	requires java.desktop;
}