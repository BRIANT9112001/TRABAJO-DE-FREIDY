package windowb;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.ComponentOrientation;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JRadioButton;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JSpinner;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class App1 implements ChangeListener, ItemListener{

	private JFrame frmEspejo;
	JRadioButton rbt1,rbt2,rbt3,rbtt1,rbtt2,rbtt3;
	JCheckBox chc1,chc2,chc3,chcc1,chcc2,chcc3;
	JSpinner sp1,sp2,sp3,spp1,spp2,spp3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App1 window = new App1();
					window.frmEspejo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public App1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEspejo = new JFrame();
		frmEspejo.setTitle("Espejo");
		frmEspejo.getContentPane().setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		frmEspejo.setBounds(100, 100, 800, 473);
		frmEspejo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmEspejo.getContentPane().setLayout(new BoxLayout(frmEspejo.getContentPane(), BoxLayout.Y_AXIS));
		
		JPanel panel = new JPanel();
		frmEspejo.getContentPane().add(panel);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		ButtonGroup rgrupo = new ButtonGroup();
		
		rbt1 = new JRadioButton("Opcion 1");
		panel.add(rbt1);
		
		rbt2 = new JRadioButton("Opcion 2");
		panel.add(rbt2);
		
		rbt3 = new JRadioButton("Opcion 3");
		panel.add(rbt3);
		
		rbt1.addChangeListener(this);
		rbt2.addChangeListener(this);
		rbt3.addChangeListener(this);
		rgrupo.add(rbt1);
		rgrupo.add(rbt2);
		rgrupo.add(rbt3);
		
		chc1 = new JCheckBox("Opcion 4");
		panel.add(chc1);
		
		chc2 = new JCheckBox("Opcion 5");
		panel.add(chc2);
		
		chc3 = new JCheckBox("Opcion 6");
		panel.add(chc3);
		
		chc1.addItemListener(this);
		chc2.addItemListener(this);
		chc3.addItemListener(this);
		
		sp1 = new JSpinner();
		panel.add(sp1);
		sp1.addChangeListener(this);
		
		sp2 = new JSpinner();
		panel.add(sp2);
		
		sp3 = new JSpinner();
		panel.add(sp3);
		
		JPanel panel_1 = new JPanel();
		frmEspejo.getContentPane().add(panel_1);
		
		rbtt1 = new JRadioButton("Opcion 1");
		rbtt1.setEnabled(false);
		panel_1.add(rbtt1);
		
		rbtt2 = new JRadioButton("Opcion 2");
		rbtt2.setEnabled(false);
		panel_1.add(rbtt2);
		
		rbtt3 = new JRadioButton("Opcion 3");
		rbtt3.setEnabled(false);
		panel_1.add(rbtt3);
		
		rbtt1.addChangeListener(this);
		rbtt2.addChangeListener(this);
		rbtt3.addChangeListener(this);
		ButtonGroup rgrupo2 = new ButtonGroup();
		rgrupo2.add(rbtt1);
		rgrupo2.add(rbtt2);
		rgrupo2.add(rbtt3);
		
		chcc1 = new JCheckBox("Opcion 4");
		chcc1.setEnabled(false);
		panel_1.add(chcc1);
		
		chcc2 = new JCheckBox("Opcion 5");
		chcc2.setEnabled(false);
		panel_1.add(chcc2);
		
		chcc3 = new JCheckBox("Opcion 6");
		chcc3.setEnabled(false);
		panel_1.add(chcc3);
		
		chcc1.addItemListener(this);
		chcc2.addItemListener(this);
		chcc3.addItemListener(this);
		
		spp1 = new JSpinner();
		spp1.setEnabled(false);
		panel_1.add(spp1);
		
		
		spp2 = new JSpinner();
		spp2.setEnabled(false);
		panel_1.add(spp2);
		
		spp3 = new JSpinner();
		spp3.setEnabled(false);
		panel_1.add(spp3);
		
		sp1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
            	spp1.setValue(sp1.getValue());
            }
        });
		
		sp2.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
            	spp2.setValue(sp2.getValue());
            }
        });
		
		sp3.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
            	spp3.setValue(sp3.getValue());
            }
        });
		
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		// TODO Auto-generated method stub
		if (rbt1.isSelected()) {
			rbtt1.setSelected(true);
		}else if(rbt2.isSelected()){
			rbtt2.setSelected(true);
		}else if(rbt3.isSelected()) {
			rbtt3.setSelected(true);
		}
		
		
		
		
		
	}
	



	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
		//dentro del metodo que identifica si hubo un cambio en el item, implementar if para ver si el check esta seleccionado, y marcar el otro, y else en caso de que no para que se deseleccione
		
		if (chc1.isSelected()) {
			chcc1.setSelected(true);
		}else {
			chcc1.setSelected(false);
		}if (chc2.isSelected()) {
			chcc2.setSelected(true);
		}else {
			chcc2.setSelected(false);
		}if(chc3.isSelected()) {
			chcc3.setSelected(true);
		}else {
			chcc3.setSelected(false);
		}
		
		
		
	}
	

	

}
