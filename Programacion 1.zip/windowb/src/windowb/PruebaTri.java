package windowb;

import java.util.Scanner;

class Triangulo{
	double ladoA, ladoB, ladoC;
	
	public Triangulo(double ladoA,double ladoB,double ladoC) {
		this.ladoA=ladoA;
		this.ladoB=ladoB;
		this.ladoC=ladoC;
	}
	
	public boolean esEscaleno() {
		return (ladoA != ladoB) && (ladoB!=ladoC)&& (ladoA !=ladoC);
	}
	
	public boolean esIsosceles() {
		return (ladoA == ladoB && ladoA != ladoC) ||
	           (ladoA == ladoC && ladoA != ladoB) ||
	           (ladoB == ladoC && ladoB != ladoA  );
	}
	 public boolean esEquilatero() {
	        return (ladoA == ladoB) && (ladoB == ladoC);
	    }
	 public boolean AngRec() {
		 double ladoA2 = Math.pow(ladoA, 2);
	     double ladoB2 = Math.pow(ladoB, 2);
	     double ladoC2 = Math.pow(ladoC, 2);
	     
	     return (ladoA2 + ladoB2 == ladoC2) ||
	            (ladoA2 + ladoC2 == ladoB2) ||
	            (ladoB2 + ladoC2 == ladoA2);
	 }
	 public void mostrarInf() {
	        System.out.println("Triángulo con lados: " + ladoA + ", " + ladoB + ", " + ladoC);
	        System.out.println("Es escaleno: " + esEscaleno());
	        System.out.println("Es isósceles: " + esIsosceles());
	        System.out.println("Es equilátero: " + esEquilatero());
	        System.out.println("Tiene ángulo recto: " + AngRec());
	        System.out.println();
	    }
}

public class PruebaTri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Triangulo triangulo1 = new Triangulo(3, 4, 5); 
	     Triangulo triangulo2 = new Triangulo(5, 5, 5);
	     
	     boolean salir = false;
	     Scanner scanner = new Scanner(System.in);
	     
	     while(!salir) {
	            System.out.println("Seleccione una opción:");
	            System.out.println("1. Mostrar información del primer triángulo");
	            System.out.println("2. Mostrar información del segundo triángulo");
	            System.out.println("3. Salir");
	            
	            int elec = scanner.nextInt();
	            
	            switch (elec) {
	            case 1:
	            	System.out.println();
	            	System.out.println("Informacion primer triangulo");
	            	triangulo1.mostrarInf();
	            	System.out.println();
	            	break;
	            case 2:
	            	System.out.println();
	            	System.out.println("Informacion segundo triangulo");
	            	triangulo2.mostrarInf();
	            	System.out.println();
	            	break;
	            case 3:
                    System.out.println("Saliendo del programa");
                    salir = true;
                    break;
	            default:
                    System.out.println("Opcion no reconocida");
	            }
	     }
	}

}
