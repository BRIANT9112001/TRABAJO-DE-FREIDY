package windowb;

import java.util.Scanner;

class Libro {
	String titulo;
	boolean original;
	boolean prestable;
	
	public Libro(String titulo, boolean original, boolean prestable) {
		this.titulo=titulo;
		this.original=original;
		this.prestable=prestable;
	}
	
	public String getTitulo() {
		return titulo;
	}
	public boolean getOriginal() {
		return original;
	}
	public boolean getPrestable() {
		return prestable;
	}
	public boolean esOriginal() {
        return original;
    }

    public boolean sePresta() {
        return prestable;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setOriginal(boolean original) {
        this.original = original;
    }

    public void setPrestable(boolean prestable) {
        this.prestable = prestable;
    }
    public void mostrar() {
    	System.out.println("Titulo: "+titulo);
    	System.out.println("Original: "+ (original ? "Si" : "No"));
    	System.out.println("Prestable: "+ (prestable ? "Si" : "No"));
    }
    
}

public class Biblioteca {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Libro libro1 = new Libro("Libro Original", true, false);
		Libro libro2 = new Libro("Fotocopia", false, true);
		
		boolean salir = false;
		Scanner scanner = new Scanner(System.in);
		
		while (!salir) {
			 System.out.println("Seleccione una opción:");
	         System.out.println("1. Mostrar información del primer libro");
	         System.out.println("2. Mostrar información del segundo libro");
	         System.out.println("3. Salir");
	         
	         int elegir = scanner.nextInt();
	         
	         switch (elegir) {
	         case 1:
	        	 System.out.println("Informacion del primer libro");
	        	 libro1.mostrar();
	        	 break;
	         case 2:
	        	 System.out.println("Informacion del segundo libro");
	        	 libro2.mostrar();	
	        	 break;
	         case 3:
	        	 System.out.println("Cerrando");
	        	 salir = true;
	        	 break;
	         default:
	             System.out.println("Opcion no valida");
	         }
		}
	}
}
