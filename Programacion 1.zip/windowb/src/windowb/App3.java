package windowb;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.swing.JSlider;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class App3 implements ActionListener, ChangeListener {

	private JFrame frmMiniEncuesta;
	JLabel labelslider;
	JCheckBox chec3,chec2,chec1;
	JRadioButton rbtn1,rbtn2,rbtn3;
	JSlider slider;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App3 window = new App3();
					window.frmMiniEncuesta.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public App3() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMiniEncuesta = new JFrame();
		frmMiniEncuesta.setTitle("Mini Encuesta");
		frmMiniEncuesta.setBounds(100, 100, 416, 477);
		frmMiniEncuesta.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		rbtn1 = new JRadioButton("Windows");
		
		rbtn2 = new JRadioButton("Linux");
		
		rbtn3 = new JRadioButton("MacOS");
		
		ButtonGroup gru = new ButtonGroup();
		gru.add(rbtn1);
		gru.add(rbtn2);
		gru.add(rbtn3);
		
		JLabel labelos = new JLabel("Elige tu sistema operativo");
		
		chec3 = new JCheckBox("Programacion");
		
		chec2 = new JCheckBox("Diseño grafico");
		
		chec1 = new JCheckBox("Administracion");
		
		JLabel labeles = new JLabel("Elige tu especialidad");
		
		slider = new JSlider();
		slider.setMaximum(12);
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
			Integer veri = slider.getValue();
			String conv = veri.toString();
			labelslider.setText(conv);
			}
		});
		
		JLabel lblho = new JLabel("Horas dedicadas al ordenador");
		
		labelslider = new JLabel("0");
		
		JButton boton = new JButton("Generar");
		boton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mensaje = "Sistema Operativo: ";
                if (rbtn1.isSelected()) mensaje += "Windows";
                else if (rbtn2.isSelected()) mensaje += "Linux";
                else if (rbtn3.isSelected()) mensaje += "Mac";

                mensaje += "\nEspecialidades: ";
                if (chec1.isSelected()) mensaje += "Programación ";
                if (chec2.isSelected()) mensaje += "Diseño gráfico ";
                if (chec3.isSelected()) mensaje += "Administración ";

                mensaje += "\nHoras en el ordenador: " + slider.getValue();
                JOptionPane.showMessageDialog(null, mensaje);
				
			}
		});
		GroupLayout groupLayout = new GroupLayout(frmMiniEncuesta.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(18)
							.addComponent(labelslider, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(rbtn2)
								.addComponent(rbtn1)
								.addComponent(chec1)
								.addComponent(chec2)
								.addComponent(chec3)
								.addComponent(rbtn3)
								.addGroup(groupLayout.createSequentialGroup()
									.addGap(10)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(slider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addComponent(boton)))))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(113)
							.addComponent(labelos))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(113)
							.addComponent(labeles))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(114)
							.addComponent(lblho)))
					.addContainerGap(186, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(6)
					.addComponent(labelos)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(rbtn1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rbtn2)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rbtn3)
					.addGap(15)
					.addComponent(labeles)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(chec3)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(chec2)
					.addGap(3)
					.addComponent(chec1)
					.addGap(14)
					.addComponent(lblho)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(labelslider, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(slider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(boton)
					.addContainerGap(144, Short.MAX_VALUE))
		);
		frmMiniEncuesta.getContentPane().setLayout(groupLayout);
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
