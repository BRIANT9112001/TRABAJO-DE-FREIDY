package windowb;

import java.util.Scanner;

class Socio{
	String nombre;
	int numero;
	
	static int proximoNumero = 1; 
	
	public Socio(String nombre) {
		this.nombre=nombre;
		this.numero=proximoNumero;
		proximoNumero++;
	}

   
    public String getNombre() {
        return nombre;
    }

    public int getNumero() {
        return numero;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void mostrarInfo() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Numero de socio: " + numero);
        System.out.println();
    }
}
	


public class Club {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Socio socio1 = null;
		Socio socio2 = null;
		boolean salir= false;
        while (!salir) {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Crear primer socio");
            System.out.println("2. Crear segundo socio");
            System.out.println("3. Mostrar datos del primer socio");
            System.out.println("4. Mostrar datos del segundo socio");
            System.out.println("5. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    if (socio1 == null) {
                        System.out.print("Ingrese el nombre del primer socio: ");
                        String nombre1 = scanner.nextLine();
                        socio1 = new Socio(nombre1);
                        System.out.println("Primer socio creado\n");
                    } else {
                        System.out.println("El primer socio ya ha sido creado\n");
                    }
                    break;
                case 2:
                    if (socio2 == null) {
                        System.out.print("Ingrese el nombre del segundo socio: ");
                        String nombre2 = scanner.nextLine();
                        socio2 = new Socio(nombre2);
                        System.out.println("Segundo socio creado.\n");
                    } else {
                        System.out.println("El segundo socio ya ha sido creado\n");
                    }
                    break;
                case 3:
                    if (socio1 != null) {
                        System.out.println("Datos del primer socio:");
                        socio1.mostrarInfo();
                    } else {
                        System.out.println("El primer socio aun no ha sido creado\n");
                    }
                    break;
                case 4:
                    if (socio2 != null) {
                        System.out.println("Datos del segundo socio:");
                        socio2.mostrarInfo();
                    } else {
                        System.out.println("El segundo socio aun no ha sido creado\n");
                    }
                    break;
                case 5:
                    System.out.println("Saliendo del programa");
                    salir = true;
                    break;
                default:
                    System.out.println("Opcion no valida");
            }
        }
	}

}
