package Empleados;

public class Empleados extends EmpleadosBase {

	public Empleados(int id, String nombre, String email, String posicion, String salario) {
		super(id, nombre, email, posicion, salario);
	}
}
