package modelocliente;


public class Cliente extends ClienteBase {
	public Cliente (int id, String nombre, String detallecontacto, String tipocontacto) {
		super(id,nombre,detallecontacto,tipocontacto);
	}
}



